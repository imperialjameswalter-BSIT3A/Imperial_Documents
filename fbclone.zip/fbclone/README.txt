LOCAL RUN
  pip install -r requirements.txt
  python manage.py makemigrations profiles
  python manage.py migrate
  python manage.py runserver

PYTHONANYWHERE DEPLOY
1. Zip upload: Files tab > upload fbclone.zip to /home/yourusername/ then in a Bash console run: unzip fbclone.zip
2. Bash console:
     cd ~/fbclone
     mkvirtualenv fbenv --python=python3.10
     pip install -r requirements.txt
     python manage.py makemigrations profiles
     python manage.py migrate
     python manage.py collectstatic
3. Web tab > Add a new web app > Manual configuration > Python 3.10.
4. Virtualenv: /home/yourusername/.virtualenvs/fbenv
5. WSGI file: replace the contents with
     import os, sys
     path = "/home/yourusername/fbclone"
     if path not in sys.path:
         sys.path.append(path)
     os.environ["DJANGO_SETTINGS_MODULE"] = "fbclone.settings"
     from django.core.wsgi import get_wsgi_application
     application = get_wsgi_application()
6. Static files table on the Web tab:
     URL /static/  ->  /home/yourusername/fbclone/staticfiles
     URL /media/   ->  /home/yourusername/fbclone/media
7. In fbclone/settings.py set ALLOWED_HOSTS = ["yourusername.pythonanywhere.com"]
8. Select Reload. Open https://yourusername.pythonanywhere.com
