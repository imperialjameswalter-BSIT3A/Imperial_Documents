from django import forms
from .models import Profile


class PictureForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ["profile_picture"]
        widgets = {"profile_picture": forms.FileInput(attrs={"accept": "image/*", "id": "picture-input"})}

    def clean_profile_picture(self):
        image = self.cleaned_data.get("profile_picture")
        if image and image.size > 5 * 1024 * 1024:
            raise forms.ValidationError("Choose an image under 5 MB.")
        return image


class DetailsForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ["name", "bio", "works_at", "studies_at", "lives_in"]
