from django.db import models


class Profile(models.Model):
    name = models.CharField(max_length=80, default="Your Name")
    bio = models.CharField(max_length=160, blank=True, default="Add a short bio")
    works_at = models.CharField(max_length=80, blank=True)
    studies_at = models.CharField(max_length=80, blank=True)
    lives_in = models.CharField(max_length=80, blank=True)
    profile_picture = models.ImageField(upload_to="profile_pics/", blank=True, null=True)

    def __str__(self):
        return self.name
