const input = document.getElementById("picture-input");
const preview = document.getElementById("avatar-preview");
const pictureForm = document.getElementById("picture-form");

input.addEventListener("change", () => {
  const file = input.files[0];
  if (!file) return;
  preview.src = URL.createObjectURL(file);
  pictureForm.submit();
});

const dialog = document.getElementById("edit-dialog");
document.getElementById("edit-btn").addEventListener("click", () => dialog.showModal());
document.getElementById("cancel-btn").addEventListener("click", () => dialog.close());

document.querySelectorAll(".like-btn").forEach((btn) => {
  btn.addEventListener("click", () => btn.classList.toggle("liked"));
});

setTimeout(() => document.querySelectorAll(".toast").forEach((t) => t.remove()), 4000);
