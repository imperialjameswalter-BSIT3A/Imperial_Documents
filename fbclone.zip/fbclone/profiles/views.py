from django.contrib import messages
from django.shortcuts import redirect, render
from .forms import DetailsForm, PictureForm
from .models import Profile


def profile_view(request):
    profile, _ = Profile.objects.get_or_create(pk=1)
    if request.method == "POST":
        if request.POST.get("form") == "picture":
            form = PictureForm(request.POST, request.FILES, instance=profile)
            if form.is_valid():
                form.save()
                messages.success(request, "Profile picture updated.")
            else:
                messages.error(request, " ".join(form.errors.get("profile_picture", ["Upload failed."])))
        else:
            form = DetailsForm(request.POST, instance=profile)
            if form.is_valid():
                form.save()
                messages.success(request, "Profile details saved.")
        return redirect("profile")
    return render(request, "profiles/profile.html", {
        "profile": profile,
        "picture_form": PictureForm(instance=profile),
        "details_form": DetailsForm(instance=profile),
        "friends": ["Ana Reyes", "Miguel Cruz", "Sofia Lim", "Jarel Santos", "Bea Ramos", "Carlo Diaz"],
    })
